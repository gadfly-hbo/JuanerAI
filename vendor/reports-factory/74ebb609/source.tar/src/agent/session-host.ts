import {
  createSessionRuntime,
  createExecutionTools,
  createLocalExecutionEnvironment,
  loadHarnessResources,
  RuntimeFault,
  type AuditEvent,
  type AuditSink,
  type Authorization,
  type BudgetStore,
  type HarnessObservation,
  type ModelConfig,
  type ModelTransport,
  type RunResult,
  type SessionInfo,
  type SessionRuntime,
  type SessionRuntimeOptions,
  type SessionStorage,
  type Tool,
  type UncappedLimits,
} from 'pi-agent-runtime';
import { mkdirSync, openSync, closeSync, unlinkSync, writeFileSync } from 'node:fs';
import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { FileBudgetStore } from './budget-store.js';
import { JsonlAuditSink } from './audit.js';
import { localAuthorize, LOCAL_POLICY_VERSION } from './authorize.js';
import type { JsonValue } from 'pi-agent-runtime';
import { proposeOutlineTool } from './tools/outline-tool.js';
import { renderDeckTool } from './tools/render-deck-tool.js';
import { lookPageTool } from './tools/look-page-tool.js';
import { createNetworkExecutionEnvironment } from './exec-env.js';
import { familyContent } from './families.js';
import { logReadPath } from './read-log.js';
import { readLockedPages, isLockedPath } from './locked-pages.js';
import { detectDrift } from './data-drift.js';
import { detectOutlineDrift } from './outline-drift.js';
import { qaDeckTool } from './tools/qa-deck-tool.js';
import { exportDeckTool } from './tools/export-deck-tool.js';
import { BUILD_SYSTEM, confirmedOutlinePrompt } from './prompts.js';
import type { OutlinePage } from './outline.js';

/**
 * 会话宿主（S2，AGENT-RUNTIME 原生 Harness 接入）：
 * 每项目一个 createSessionRuntime 实例 + 一个持续原生会话（JSONL 落盘，重启恢复）。
 * 适配层边界：本目录（src/agent/）是业务代码唯一触达 pi-agent-runtime 的位置。
 *
 * 宿主输入（INTEGRATION 五输入）：显式 transport（model.ts）、授权（authorize.ts）、
 * 预算（budget-store.ts，uncapped）、审计（audit.ts）、工具（原生 read/write/edit/bash + 自定义）。
 */

/** 用途标识（审计与 UI 归类用；未声明 purposes 集合时 run 不传 purpose——SDK 合同）。 */
export const PURPOSE = 'ppt-build';

/** 单次保护必填（uncapped 合同）：输出/模型/工具/控制 IO 各自独立计时封顶。 */
export const UNLIMITED_LIMITS: UncappedLimits = {
  cumulative: 'unlimited',
  maxOutputTokens: 32_768, // 与主模型单次输出上限一致（T3 真调教训：写代码轮 8192 不够）
  modelTimeoutMs: 600_000,
  toolTimeoutMs: 300_000, // 硬墙须宽于 env 软超时——慢命令先被软超时转为可恢复工具错误，而非杀死整个 run（flow-18 e2e 事故）
  controlTimeoutMs: 30_000,
};

/** bash 软超时（先于 SDK 硬墙触发）：超时返回可恢复错误文本（exitCode 124）给 agent 自纠。 */
export const EXEC_SOFT_TIMEOUT_MS = 120_000;

export interface SessionHostOptions {
  /** 项目数据根（data/<proj> 绝对路径）——会话 JSONL 与受限执行环境的边界 */
  projectRoot: string;
  /** PPT skill 目录（assets/skills/ppt） */
  skillsDir: string;
  model: ModelConfig;
  transport: ModelTransport;
  fallbacks?: ReadonlyArray<{ model: ModelConfig; transport: ModelTransport }>;
  /** 审计/账本文件（缺省 data/ 下中心文件） */
  auditFile?: string;
  budgetFile?: string;
}

export interface AgentEventForUi {
  at: string;
  kind: string;
  detail?: Record<string, unknown>;
}

/** 操作绑定持久文件（bindOperation 的幂等凭据 + reconcile 的对账依据）。 */
interface OperationBindings {
  version: 1;
  operations: Record<string, { taskId: string; purpose?: string }>;
}

export class SessionHost {
  readonly taskId: string;
  private readonly projectRootDir: string;
  private readonly runtime: SessionRuntime;
  private session: SessionInfo | null = null;
  private readonly tools: readonly Tool[];
  private activeRun: Promise<RunResult<string>> | null = null;
  private lastOutcome: RunResult<string> | null = null;
  private readonly events: AgentEventForUi[] = [];
  private readonly eventListeners = new Set<(e: AgentEventForUi) => void>();
  private closed = false;

  private constructor(runtime: SessionRuntime, taskId: string, projectRootDir: string, tools: readonly Tool[]) {
    this.runtime = runtime;
    this.taskId = taskId;
    this.projectRootDir = projectRootDir;
    this.tools = tools;
  }

  // ---- 事件（SSE 数据源；真实事件，零内容）----

  private recordEvent(e: AgentEventForUi): void {
    this.events.push(e);
    if (this.events.length > 500) this.events.splice(0, this.events.length - 500);
    for (const l of this.eventListeners) {
      try { l(e); } catch { /* 观察者异常不影响运行 */ }
    }
  }

  subscribe(listener: (e: AgentEventForUi) => void): () => void {
    this.eventListeners.add(listener);
    return () => this.eventListeners.delete(listener);
  }

  recentEvents(): AgentEventForUi[] {
    return [...this.events];
  }

  // ---- 装配 ----

  static async create(opts: SessionHostOptions): Promise<SessionHost> {
    const sessionRoot = join(opts.projectRoot, 'session');
    mkdirSync(sessionRoot, { recursive: true });
    mkdirSync(join(opts.projectRoot, 'work'), { recursive: true });

    // 专业内容：原生 skills 装载（宿主指定可信源）；家族目录与之同源（R7-1：不再自造路径）
    if (process.env['REPORT_STUDIO_SKILLS_DIR']) process.env['REPORT_STUDIO_SKILLS_DIR'] = opts.skillsDir;
    const resources = await loadHarnessResources({
      cwd: opts.projectRoot,
      sources: [{ kind: 'skills', path: opts.skillsDir, version: LOCAL_POLICY_VERSION }],
      authorize: async () => true,
    });
    for (const d of resources.diagnostics) {
      console.error(`[skills] ${d.kind}: ${d.path}`);
    }

    // 联网执行环境（flow-2 U4，运行条件对齐 C4）：exec 无网络沙箱（可装库/取素材），
    // 文件面仍限项目根；授权/审计/单次超时保持（对齐 pi-coding-agent 的 bash 自由度）
    const env = await createNetworkExecutionEnvironment({
      root: opts.projectRoot,
      policyVersion: 'report-studio-net-v1',
      execTimeoutMs: EXEC_SOFT_TIMEOUT_MS,
    });
    const nativeTools = createExecutionTools(env, ['read', 'write', 'edit', 'bash']);
    const outlineTool = proposeOutlineTool(opts.projectRoot);
    const renderDeck = renderDeckTool(opts.projectRoot);
    const qaTool = qaDeckTool(opts.projectRoot);
    const exportTool = exportDeckTool(opts.projectRoot);
    const lookPage = lookPageTool(opts.projectRoot);
    // 宿主软化策略（P2/P3）：文件类工具失败转 JSON 错误文本回模型自纠，不终止整轮
    // （SDK 默认 after_tool 对 isError 直接 TOOL_FAILED 杀运行——对 read 路径猜测失败这类可自纠错误过严）。
    // 授权/预算/审计仍发生在每次准入边界，软化不绕过任何护栏。
    const soft = (t: Tool): Tool => ({
      ...t,
      execute: async (args, signal, invocation) => {
        try {
          // 页锁定防御（flow-10 P2-2）：write/edit 不能碰锁定页
          if (t.name === 'write' || t.name === 'edit') {
            const p = (args as { path?: unknown }).path;
            if (typeof p === 'string') {
              const locked = await readLockedPages(opts.projectRoot);
              if (isLockedPath(locked, p)) {
                const errPayload = { ok: false, error: `该页已锁定（用户手工定稿），不可修改：${p}。请只修改未锁定的页。` };
                return t.output === 'content'
                  ? { content: [{ kind: 'text', text: JSON.stringify(errPayload) }], details: null }
                  : errPayload;
              }
            }
          }
          const out = await t.execute(args, signal, invocation);
          if (t.name === 'read') {
            const p2 = (args as { path?: unknown }).path;
            if (typeof p2 === 'string') void logReadPath(opts.projectRoot, p2); // 覆盖门数据源（D2）
          }
          return out;
        } catch (e) {
          const error = String(e instanceof Error ? e.message : e).slice(0, 300);
          const payload: JsonValue = { ok: false, error, retry_hint: '工具执行失败：检查路径/参数后重试（read 支持项目根相对路径）' };
          // output:'content' 工具须返回 content 形状（SDK 校验 content 数组，缺它即 TOOL_FAILED）
          if (t.output === 'content') {
            return { content: [{ kind: 'text', text: JSON.stringify(payload) }], details: null };
          }
          return payload;
        }
      },
    });

    const auditFile = opts.auditFile ?? join(opts.projectRoot, '..', 'agent-audit.jsonl');
    const budgetFile = opts.budgetFile ?? join(opts.projectRoot, '..', 'agent-budget.json');
    const audit: AuditSink = new JsonlAuditSink(auditFile);
    const budgets: BudgetStore = new FileBudgetStore(budgetFile);
    const authorize = localAuthorize();
    const taskId = `task_${sessionIdOf(opts.projectRoot)}`;

    const operationsFile = join(opts.projectRoot, 'work', 'agent-operations.json');
    const bindOperation: SessionRuntimeOptions['bindOperation'] = async (input) => {
      const bindings = await readBindings(operationsFile);
      const known = bindings.operations[input.operationId];
      if (known) {
        if (known.taskId !== input.taskId || (known.purpose ?? undefined) !== (input.purpose ?? undefined)) {
          throw new RuntimeFault('INVALID_REQUEST');
        }
        return; // 幂等重复确认
      }
      bindings.operations[input.operationId] = { taskId: input.taskId, purpose: input.purpose };
      await writeBindings(operationsFile, bindings);
    };
    const reconcile: SessionRuntimeOptions['reconcile'] = async (input) => {
      const bindings = await readBindings(operationsFile);
      for (const op of input.open) {
        if (!bindings.operations[op.operationId]) return 'unknown'; // 未知开放操作拒绝推进
      }
      return 'ready';
    };

    // 工具耗时（W2.1 工具动作卡「完成（含耗时）」）：admitted 记起点，finished 配对算差
    const toolStart = new Map<string, number>();
    const onAudit = (e: Readonly<AuditEvent>) => {
      if (e.kind === 'tool.admitted') toolStart.set(e.toolName ?? '', Date.parse(e.at));
      const durationMs = e.kind === 'tool.finished' && toolStart.has(e.toolName ?? '') ? Date.parse(e.at) - (toolStart.get(e.toolName ?? '') ?? 0) : undefined;
      if (e.kind === 'tool.finished') toolStart.delete(e.toolName ?? '');
      hostRef?.recordEvent({ at: e.at, kind: e.kind, detail: { provider: e.provider, model: e.model, toolName: e.toolName, reason: e.reason, attempt: e.attempt, failed: e.toolFailed, ...(durationMs !== undefined ? { durationMs } : {}) } });
    };
    let hostRef: SessionHost | null = null;

    const runtime = createSessionRuntime({
      model: opts.model,
      transport: opts.transport,
      fallbacks: opts.fallbacks,
      authorize,
      audit,
      budgets,
      storage: await projectSessionStorage(sessionRoot),
      harness: {
        skills: resources.skills,
        templates: resources.templates,
        // 原生压缩开启（持续任务）；retry 必须关闭（uncapped 合同：modelRecovery 单次额外尝试）
        compaction: { enabled: true, reserveTokens: 4096, keepRecentTokens: 8192 },
        steeringMode: 'all',
        followUpMode: 'all',
      },
      bindOperation,
      reconcile,
      onEvent: onAudit,
      onHarnessEvent: (e: HarnessObservation) => {
        hostRef?.recordEvent({ at: new Date().toISOString(), kind: `harness:${e.kind}` });
      },
    });

    const host = new SessionHost(runtime, taskId, opts.projectRoot, [outlineTool, renderDeck, qaTool, exportTool, lookPage, ...nativeTools].map(soft));
    hostRef = host;
    host.session = await host.findOrCreateSession();
    return host;
  }

  private async findOrCreateSession(): Promise<SessionInfo> {
    const existing = await this.runtime.list();
    const latest = existing.sort((a, b) => b.createdAt - a.createdAt)[0];
    if (latest) return latest;
    return this.runtime.create();
  }

  get sessionId(): string | null {
    return this.session?.id ?? null;
  }

  isBusy(): boolean {
    return this.activeRun !== null;
  }

  defaultTools(): readonly Tool[] {
    return this.tools;
  }

  /** 发送消息（prompt）。已有运行在推进时转 steer（对话式插话）；否则开新 run。 */
  async send(text: string, opts: { system?: string } = {}): Promise<{ mode: 'steer' | 'run' }> {
    // 场景家族（flow-7）+ 企业 VI（flow-9）：并入 system（每 run 注入；降级不阻断）
    const family = opts.system ? '' : await this.projectFamily();
    const brand = opts.system ? '' : await this.projectBrand();
    const locked = opts.system ? '' : await this.projectLocked();
    const drift = opts.system ? '' : await this.projectDrift();
    const outlineDrift = opts.system ? '' : await this.projectOutlineDrift();
    const system = [opts.system ?? BUILD_SYSTEM, family.trim(), brand.trim(), locked.trim(), drift.trim(), outlineDrift.trim()].filter(Boolean).join('\n\n');
    if (this.closed) throw new Error('宿主已关闭');
    if (this.activeRun) {
      await this.control({ kind: 'steer', text });
      return { mode: 'steer' };
    }
    const session = this.session ?? (this.session = await this.findOrCreateSession());
    this.recordEvent({ at: new Date().toISOString(), kind: 'chat:user_send' });
    const run = this.runtime.run({
      sessionId: session.id,
      taskId: this.taskId,
      prompt: text,
      system,
      tools: this.tools,
      limits: UNLIMITED_LIMITS,
      thinkingLevel: 'medium', // flow-2 U2：对齐 pi-coding-agent 运行条件（U0 双链 probe 实证）
      modelRecovery: { extraAttempts: 1 },
    });
    this.activeRun = run;
    void run.then(
      (r) => { this.lastOutcome = r; },
      (e) => {
        // SDK 面上 run 不应 reject；防御性兜底为 failed 结果（R1-2：停止/失败后前端必须能退出 busy）
        this.lastOutcome = { taskId: this.taskId, runId: 'unknown', status: 'failed', reason: 'MODEL_FAILED', usage: { modelCalls: 0, toolCalls: 0, outputTokens: 0, resourceUnits: 0, activeMs: 0 }, usageKnown: false };
        void e;
      },
    );
    void run.finally(() => {
      this.activeRun = null;
    }).catch(() => { /* finally 上的 catch 防御未处理拒绝 */ });
    return { mode: 'run' };
  }

  /** 等待当前 run 结束并取结果（聊天端点轮询/长轮询用；无活动 run 返回 null）。 */
  async currentResult(): Promise<RunResult<string> | null> {
    return this.activeRun;
  }

  /** 最近一次已结束的结果（R1-2：停止/快速失败后前端退出 busy 的依据；无则 null）。 */
  outcome(): RunResult<string> | null {
    return this.lastOutcome;
  }

  /** 数据变更指令（data-drift；材料更新时提醒 agent 重读）。 */
  private async projectDrift(): Promise<string> {
    const drift = await detectDrift(this.projectRootDir);
    if (drift.changed_sources.length === 0) return '';
    const sources = drift.changed_sources.map((c) => c.filename).join('、');
    const numbers = drift.changed_sources.flatMap((c) => c.changed_numbers).slice(0, 8).join('、');
    return `【数据已更新】以下材料已重新上传且数字有变更：${sources}（变更的数字：${numbers}…）。请用 read 工具重新读取这些材料的最新提取文本，受影响的页（${drift.affected_pages.join('、')}）需用新数据重新生成。`;
  }

  /** 大纲变更指令（outline-drift，B4）：确认大纲已改 → 受影响页重生成（跳过锁定页）+ 新增章节生成。 */
  private async projectOutlineDrift(): Promise<string> {
    const drift = await detectOutlineDrift(this.projectRootDir);
    if (!drift.changed) return '';
    const parts: string[] = [];
    if (drift.changed_pages.length > 0) {
      parts.push(`以下章节已改题（${drift.changed_pages.map((c) => `${c.page}「${c.old_title}」→「${c.new_title}」`).join('、')}），对应页需按新标题重新生成`);
    }
    if (drift.removed_pages.length > 0) {
      parts.push(`以下章节已从大纲移除（${drift.removed_pages.map((c) => `${c.page}「${c.title}」`).join('、')}），对应页应删除并在 deck.mjs 同步移除 import`);
    }
    if (drift.added_titles.length > 0) {
      parts.push(`大纲新增章节：${drift.added_titles.join('、')}——需新写对应页代码并在 deck.mjs 登记`);
    }
    return `【大纲已更新】用户已确认新框架：${parts.join('；')}。受影响页：${drift.affected_pages.length > 0 ? drift.affected_pages.join('、') : '（无既有页，仅新增）'}。重新生成时跳过锁定页，全部改完后 render_deck 并逐页 look_page。`;
  }

  /** 锁定页指令（locked-pages；手工定稿页不可修改）。 */
  private async projectLocked(): Promise<string> {
    const locked = await readLockedPages(this.projectRootDir);
    if (locked.length === 0) return '';
    return `【页锁定】以下页已由用户锁定为手工定稿，禁止修改其代码文件：${locked.join('、')}。重新生成/改写时跳过这些页（render_deck 仍渲染全部，锁定页文件不变即结果不变）。`;
  }

  /** 企业 VI 指令（brand；主色替换 theme.primary、Logo 引用、字体覆盖）。 */
  private async projectBrand(): Promise<string> {
    try {
      const { readFile } = await import('node:fs/promises');
      const project = JSON.parse(await readFile(join(this.projectRootDir, 'project.json'), 'utf-8')) as { brand?: { primary?: string; logo_path?: string; font_zh?: string } };
      if (!project.brand) return '';
      const parts: string[] = ['【品牌配置】'];
      if (project.brand.primary) parts.push(`theme.primary 替换为 "${project.brand.primary.replace('#', '')}"（不带#，pptxgenjs 格式）；封面/页眉/标题条用该色。`);
      if (project.brand.logo_path) parts.push(`Logo 文件路径 "${project.brand.logo_path}"——封面右下或页眉用 addImage({ path, sizing:{type:"contain",w:1.2,h:0.5} }) 引用。`);
      if (project.brand.font_zh) parts.push(`中文字体全部用 "${project.brand.font_zh}"（fontFace 参数）。`);
      return parts.join('\n');
    } catch { return ''; }
  }

  /** 项目的场景家族配方（ppt_family；读不到/未设 → 默认家族）。 */
  private async projectFamily(): Promise<string> {
    try {
      const { readFile } = await import('node:fs/promises');
      const project = JSON.parse(await readFile(join(this.projectRootDir, 'project.json'), 'utf-8')) as { ppt_family?: string };
      return await familyContent(project.ppt_family);
    } catch {
      return familyContent(null);
    }
  }

  /** 框架确认注入（outline/confirm 路由调用）：把确认大纲作为一次推进发给会话。 */
  async notifyOutlineConfirmed(version: number, pages: OutlinePage[]): Promise<{ mode: 'steer' | 'run' }> {
    return this.send(confirmedOutlinePrompt(version, pages));
  }

  async control(command: { kind: 'steer' | 'followUp' | 'nextRun' | 'abort'; text?: string }): Promise<void> {
    if (!this.session) throw new Error('会话不存在');
    const kind = command.kind === 'abort' ? { kind: 'abort' as const } : { kind: command.kind, text: command.text ?? '' };
    await this.runtime.control({ taskId: this.taskId, sessionId: this.session.id, command: kind });
  }

  async snapshot() {
    if (!this.session) throw new Error('会话不存在');
    const r = await this.runtime.control({ taskId: this.taskId, sessionId: this.session.id, command: { kind: 'snapshot', includeContent: false } });
    return r.snapshot;
  }

  async history() {
    if (!this.session) return [];
    return this.runtime.history(this.session.id);
  }

  async close(): Promise<void> {
    this.closed = true;
    // 释放 storage writer 锁由 runtime/storage 层负责；这里停止事件与后续 run
    this.eventListeners.clear();
  }
}

// ---- 项目会话存储（SessionStorage 宿主实现：专属根 + 跨进程 lockfile 单写入者）----

/** 进程内共享所有者：同进程多 host 实例=同一写入者；跨进程由 O_EXCL lockfile 互斥。 */
const writerLocks = new Map<string, { fd: number; holders: number }>();

async function projectSessionStorage(sessionRoot: string): Promise<SessionStorage> {
  const lockPath = join(sessionRoot, '.writer-lock');
  return {
    directory: sessionRoot,
    cwd: sessionRoot,
    policyVersion: LOCAL_POLICY_VERSION,
    authorize: async () => true, // 本地单用户：专属根目录即访问边界（无跨项目访问）
    acquireWriter: async () => {
      const existing = writerLocks.get(sessionRoot);
      if (existing) {
        existing.holders += 1;
        let released = false;
        return {
          release: async () => {
            if (released) return;
            released = true;
            existing.holders -= 1;
            if (existing.holders === 0) {
              closeSync(existing.fd);
              try { unlinkSync(lockPath); } catch { /* 已被清理 */ }
              writerLocks.delete(sessionRoot);
            }
          },
        };
      }
      mkdirSync(sessionRoot, { recursive: true });
      let fd: number;
      try {
        fd = openSync(lockPath, 'wx');
        writeFileSync(lockPath, String(process.pid), 'utf-8');
      } catch {
        // 已有跨进程写入者：拒绝争用，不抢占活动/未对账 owner
        throw new RuntimeFault('TASK_BUSY');
      }
      writerLocks.set(sessionRoot, { fd, holders: 1 });
      return {
        release: async () => {
          const entry = writerLocks.get(sessionRoot);
          if (!entry) return;
          entry.holders -= 1;
          if (entry.holders === 0) {
            closeSync(entry.fd);
            try { unlinkSync(lockPath); } catch { /* 已被清理 */ }
            writerLocks.delete(sessionRoot);
          }
        },
      };
    },
  };
}

// ---- 操作绑定持久化 ----

async function readBindings(file: string): Promise<OperationBindings> {
  try {
    const raw = JSON.parse(await readFile(file, 'utf-8')) as OperationBindings;
    if (raw.version === 1 && raw.operations && typeof raw.operations === 'object') return raw;
  } catch { /* 首次/缺失 → 空表 */ }
  return { version: 1, operations: {} };
}

async function writeBindings(file: string, bindings: OperationBindings): Promise<void> {
  await writeFile(file, JSON.stringify(bindings, null, 1), 'utf-8');
}

/** 项目数据根目录名（…/data/proj_xxx → proj_xxx）。 */
function sessionIdOf(projectRoot: string): string {
  const parts = projectRoot.split(/[\\/]/).filter(Boolean);
  return parts[parts.length - 1] ?? 'unknown';
}
