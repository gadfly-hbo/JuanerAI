# 新运行合同 · 新架构 v1.2 · 0.6.0-newarch.1

本合同只适用于本线 B_PASS 后的新候选。旧 Task、Session、账本、配置身份与记录不读、不迁移、不恢复。候选身份及实际验证见本批 C 收据；本文本身不是 C_PASS、产品采用或 Provider 通过。

## 已批准接点和职责

公共 factory 保留 createRuntime、createSessionRuntime、Worker/Text/Agent 和原生持续 Session，只有一个 Pi Harness 实现。contextAdmission、显式 budgets、可靠 audit/authorize 和 work 绑定是必要合同；不提供旧 opt-in、隐式内存账本或旧 hash 回退。

工具只注册一份 parameters。静态合同自动可声明/可调用；可选受信 toolPolicy.view 只收窄固定能力，校验/原生准备/整批屏障始终有效。correctionLimit 仅为0或1，不另增恢复次数。Pi 决定正常工具多轮；业务资格和成果由宿主决定。

## work 的公开持久接点

每次运行提供 work={ref,chain,limit}：ref是可信业务工作根，chain是宿主已授权正常命令的稳定关联，不因UUID、purpose、run、Session或Fork生成新余额。limit初次固定为0或1。宿主持久Adapter必须核对既有可信工作根和命令/Task关联；模型文本或SDK随机ID不能创建业务授权。

BudgetStore.work提供两项原语：只读read和atomic。atomic在同一work持久事务/锁中读取SDK拥有的中立记录，执行SDK同步transition，持久提交记录后才返回value。异常必须回滚；提交ACK未知必须抛错，绝不返回新鲜发送权。宿主只实现原子、耐久、幂等和可信业务关联/停止校验，不写恢复分类或余额镜像。SDK记录是协议持久槽，不是业务库表结构。

SDK持有绑定、物理attempt、恢复父关联、原子预留、一次发送认领、终结和停止规则；同W的C+U+R≤limit≤1。normal不占恢复槽，仍逐次计量审计。G保留授予历史，不是everGranted永久拒绝位。相同申请重复读回不另授发送权，冲突绑定拒绝，换ID不能重放已停止链。

NS-01：L1严格可信not-sent/terminal/late=false/usageFinal/输入输出known-zero且无在途子动作，经持久核销后仅释放其未消费R；保留G1和L1停止，实际发送0。同W独立合法L2再遇既有R4故障，C=U=R=0时新原子授予并发送一次，G可为2、实际额外发送仍1。重复L1核销不能释放L2；已发/UNKNOWN不释放、不重放，取消和迟到不恢复资格。

持久发送认领不是已发HTTP证明，更不承诺跨HTTP/存储exactly-once。进入transport也不是已发。createPiTransport在真实fetch接缝执行一次准入；受信自定义transport必须履行同一公开发送合同。审计/账本/关联/权限/取消/硬超时失败关闭准入；未知或ACK不明保守占用，绝不用新ID再领。

公开类型见 `dist/types.d.ts`：`WorkPersistence.read(work, signal)` 与泛型 `atomic(binding, transition, signal)`；transition 同步返回 `{record, value}`，由宿主持久化整个不透明 record。`WorkBinding` 包含 work、taskId、purpose、SDK runId、configuration、可用的原生 session/operation 以及 bind/prepare/claim/settle/stop 动作。宿主须在锁内校验既有可信正常命令、跨 Task/work/operation 关联和显式停止事实；SDK 的随机 run/attempt ID 不是业务授权。存储回调不得发送模型/工具、执行业务或启动异步子动作，必须串行化同 work，不能只先读后写。事务失败不得部分写；提交已成但 ACK 不明必须抛错，保留占用供读回，不重新执行。

SDK 不透明记录是唯一恢复权威，包含不可变 Task 配置、chain 停止和 attempt/父关联/认领/终结及迟到事实。`inspectWork` 只读投影 G/C/U/R/knownExtraSent，不是另一个计数器。恢复请求 claimed 尚无可靠终结时保守占 R；跨 run 对此 work 的新绑定会关闭，避免用新 Task 绕过认领未知。同 chain 的未结算预留也拒跨 run 重开。knownExtraSent 只数已确认收到响应的额外请求；UNKNOWN 不能据此称实际发送0。核销严格按原 attempt 匹配；迟到事实追加，不覆盖原返回快照或释放 C/U。

模型授权 action 明示 phase=prepare/dispatch；最后一次发生在实际 fetch 前。自定义 `ModelTransport` 必须将真实 IO 包在 `request.dispatch` 内（每物理请求至多一次），并报告绑定本候选的完整 `ModelOutcome`；错误分类不能来自异常文本。缺发送门、未知物理状态、不完整最终用量或矛盾计数关闭成功发布与自动恢复；已报部分用量和未结预留保留。`usageKnown` 表示资源账本可读，具体 Provider presence/UNKNOWN 看 modelOutcome/modelAttempts，不能解释成最终账单完整。

## 工具反馈与效果

结构/原生准备/整批替参拒绝在executor前可证明无效果，提供有界isError给Pi下一正常步骤。自定义executor的前置拒绝通过SDK给本次调用绑定的上下文载体据实报告terminal/无效果/无在途子动作，宿主对业务内部事实负责；任意Error、工具标签、reason文本或receipt不构成证明。

区分not-started、started/partial、completed、unknown及结果交付状态。已完成后投影/保存/审计失败保留完成与receipt；UNKNOWN或未确认无效果保持硬停。真实授权失败、越界、撤权、取消、硬超时、审计/账本/绑定故障不能降格为普通反馈。普通自纠只使用原有纠正上限，不耗用或增授故障恢复额度。

## 新 Session 来源和只读

专属根与新合同来源标记在任何原生旧格式迁移/repair或写入前核对；未知、旧v3/v4、损坏尾部不能因原生可修复而被接受。SDK仅核对来源与完整性，不写旧格式parser/迁移器。

查询create之外的list/history/inspectFacts/result是被动读，无writer、repair、Provider、工具或自动推进；内容查询与安全元数据有明确授权。新合同自身正常保存、被动重开、Fork和授权显式续接保留；未结算/UNKNOWN/撤权不续接。原生Session/operation/queue为协议权威，投影不是第二状态机。

Skill/模板复用原生loader，授权覆盖实际realpath和内容版本，symlink/越界拒绝。文件read分页与压缩复用原生；0.86.1 read不是底层流式读取，工具提示不授bash权限。不新建文件/搜索/Skill平台。

Session 根只能保存本合同原生 JSONL 与来源标记；writer 锁、业务库与资源文件放在根外。来源标记固定规范根、cwd/policyVersion、Session/Task配置/work 关联及原生文件 bytes/SHA256。正常 close 后才封存新指纹；未知复制、根重定向、硬链/符号链、未封存崩溃写入和损坏尾部会在原生 open/repair 前关闭。当前候选不提供未封存写入的自动修复/恢复工具，不把其可读 JSON 当来源证明；保留原字节/账本/UNKNOWN。正常封存重开与 Fork 已验证。被动查询前后核对指纹，无 writer、repair 或自动执行。

Loader 在实际目录/文件的每次读取前按 source kind/version/path 授权，校验 realpath/链接/内容变动，返回冻结的原生 Skill/模板内容快照与摘要；运行消费这个已授权快照，不再按文件名偷偷重读变更内容。新内容须显式重新加载与绑定。宿主直接提供内联内容时自行对来源、权限和版本负责。

中立参数：主/备输出 32768/16384，模型600000ms，工具硬300000ms，控制30000ms，适用命令软120000ms，累计 unlimited。SDK不按同名数字新增总300秒或阶段60/120秒；真实授权有效期/专业计算和环境硬保护仍有效。命令软超时是 native bash 参数 `timeout`（秒）交给宿主，不冒充硬杀，宿主环境可另设真实硬保护。model/contextWindow/overhead/safetyMargin 必须由宿主按实际候选验证后提供；本轮合成数值不是 Provider 能力结论。

## 验证与授权

批准的公开验证接点为SDK factory/exports、真实Pi协议与工具链、BudgetStore.work公开持久原语、受限资源和同一精确tgz消费者。E01–E12、F1-D01–D22与NS-01为验收预期，运行证据逐项另记。源树、安装包、合成机制、真实Provider、Mini接线/产品质量、CI分别声明；不以旧PASS替代新对象。

用户本次明确授权SDK工程冻结必要签名、关联、原子性/失败语义；无需重新索取接口命名/持久接点启动审批。结构核对只收束既批F1，不代Mini设计业务表。测试seam已由本次Prompt及上述E/F1案例批准，无需再询问同一接点。真实Provider、产品操作、Git交付/发行及生产另行授权；固定C后停，独立核验由用户手动转交。


## 2026-10-26 NR03 原生前效果拒绝修复预期

仅在固定原生 factory 调用内，以本次 capability 调用的实际进入、结算、失败与取消事实证明：尚未进入修改/进程能力、无在途操作、无主机失败、无 memo/update 等控制操作失效时，原生自身抛出的普通拒绝可经现有 scoped refusal 交回 Pi。原生错误消息仅用于反馈，不作为分类证据。既有 correctionLimit 不扩大，SDK 不纠正参数/重复执行，也不复制原生分页/编辑算法。主机普通错误即使正文与原生错误相同也不能获得无效果资格；权限/撤权/取消/超时、主机 UNKNOWN、效果后/审计故障仍停止。原 C 包/源码/安装、历史消费及 UNKNOWN 不改；修复制作新本地 SDK 候选，受影响独立核验后才考虑产品采用。

验收 NR03-01 越末尾与同类原生前置拒绝准确反馈及正常后续；NR03-02 有界纠正与共享恢复槽不变；NR03-03 主机/权限/取消/迟到/效果后/审计失败反例；NR03-04 产品实际 Adapter 与 Workspace 保存/后核验/重开回归。只离线合成，不触网、不调用 Provider。
