# Pi Agent 接入基础包

本线新架构候选为 `0.6.0-newarch.1`，当前公共运行合同见 [NEW-RUNTIME-CONTRACT.md](docs/NEW-RUNTIME-CONTRACT.md)。这是破坏性本地候选：必要门禁始终生效，运行必须显式提供 contextAdmission、budgets/work、modelRecovery 和可信 work 关联；旧 Task/Session/账本/记录及 opt-in 配置不迁移、不恢复。既有产品与历史包保留原身份，安装与采用需另行授权。

## GitHub 与发行包

公开源码仓库：[gadfly-hbo/pi-agent-runtime](https://github.com/gadfly-hbo/pi-agent-runtime)。0.5.1 通过 GitHub Release 分发，校验值与筛选证据见 [发布材料](artifacts/public/v0.5.1/RELEASE-NOTES.md)。不发布 npm；所有历史固定包及收据保留。历史本机证据保留、不随Git公开；同步规则见 [GIT-WORKFLOW.md](docs/GIT-WORKFLOW.md)。

## 本地检查

开发操作见源码仓库根的 `AGENTS.md`（不是发行包的运行合同）；运行标准、SDK
公共合同。
已验证工具链：Node 24.21.0、npm 11.19.0。只在环境缺失或依赖树确需重建且已有
安装授权时运行 `npm ci --ignore-scripts`，不把重装依赖作为每次检查的前置步骤。

以下是既有检查的运行时机，不增加审批阶段；命令定义以 `package.json` 为准。

| 时机 | 检查与完成范围 |
|---|---|
| 日常修改 | 根据实际影响选择 `node --experimental-strip-types --test tests/<受影响文件>.test.ts`；TypeScript 改动补 `npm run typecheck`，入口/依赖变化补适用合同检查。尽早走实际 SDK 调用路径，不逐编辑全量回归或打包。 |
| 完整工程结果 | 固定候选，集中运行 `npm run verify`、`npm run example` 及当前合同要求的适用消费者/回归，再独立审查；修正只补失效证据与关联风险。纯文档用一致性和独立审查。 |
| 候选包交付／正式发布 | 保留公共导出/中立类型，以及适用的原生会话/Harness 消费者验证。交付任何候选包均绑定实际 `.tgz`、bytes/SHA256、内容及消费者结果；正式发布还核对 Tag/Release 与下载读回。 |

`verify` 包含类型、核心测试、构建；默认会跳过需显式启用的 OS sandbox
项。按影响及当前合同，在有效主机授权内用
`PI_RUN_OS_SANDBOX_TESTS=1 npm run verify` 补测；
未运行时写明 SKIP/范围，不能把默认验证称为完整机制零跳过验证。

先在独立构建目录执行 `npm run build`，再一次 `npm pack --ignore-scripts --pack-destination <候选目录>` 并固定字节。随后运行 `node tools/verify-package.mjs /absolute/candidate.tgz`；`verify:harness-package` 使用同一核验器。工具不会构建或重新打包，离线安装自己的精确依赖/lock，核验公共导出、类型、实际加载入口与原生 Pi HTTP DTO、工具、持续 Session 和持久 work 消费者。设置 `npm_config_cache` 指向已有精确依赖缓存；可用 `PI_CONSUMER_ROOT` 保存完整消费者与日志。安装/主机权限仍以当前任务为准。源码与包分别绑定，源树通过不能代替包通过。

测试与 `example` 使用合成模型数据；真实 Provider 只在任务需要且已有匹配授权时
有界验证，离线结果不证明真实模型质量或产品采用。SDK 发布与消费者采用分开，
见 [Git 工作流](docs/GIT-WORKFLOW.md) 和当前版本合同；本地检查不是托管 CI。

## 历史版本记录（按当时时点阅读）

## SDK0.3.1 compatibility candidate

Immutable per-task purpose plans support tool analysis and no-tool report phases under one budget. See docs/RELEASE-v0.3.1.md. Original0.3.0 releases and evidence are unchanged. Product adoption, live-provider verification and independent acceptance remain separate.

## SDK 0.3.2 检查点候选

新增中立 checkpoint、持久确认、业务等待和显式续接，合同见 [RELEASE-v0.3.2.md](docs/RELEASE-v0.3.2.md)。本机应用／读回证据在 [applied.json](artifacts/juanerai-checkpoint-20261009-001/applied.json)；该记录与历史合同中的当时状态分别保留。原生 Harness、Skills、自动压缩和完整原生恢复仍待接入，不能因包已固定而宣称 JuanerAI 生产入口已采用。
