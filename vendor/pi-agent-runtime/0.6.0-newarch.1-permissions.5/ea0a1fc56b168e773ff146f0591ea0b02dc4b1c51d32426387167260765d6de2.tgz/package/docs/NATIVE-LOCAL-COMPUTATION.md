# Native local computation (forward local candidate)

Same pinned Pi core/ai 0.86.1; no coding-agent CLI/extension dependency. createExecutionTools continues to use native read/write/edit/bash factories. Fresh delegated Sessions share public work accounting/recovery and per-operation protection.

createLocalExecutionEnvironment supports ordinary fork, multiple commands, pipelines and supplied read-only runtimeDirectories. No parent process environment is inherited. macOS file/network policy remains deny-default with explicit root/runtime/system grants. processScope excludes protected root subtrees from process reads and writes; readOnlyPaths can grant exact approved files without granting writes or their whole directory. The host must bind and recheck source/asset identities and authorization. runtimeDirectories are trusted component locations, never model-controlled file grants.

The owned shell process group is killed on cancellation, hard timeout and completion. This is the native trusted-local process model, not an enterprise adversarial process isolation guarantee. Review must distinguish normal child settlement from deliberately detached processes; no stronger guarantee is inferred from native Pi parity.

commandSoftTimeoutMs is a notice and does not terminate work. timeoutMs remains the hard local leaf protection; native model-specified optional timeout is separate. Soft notices are retained with the settled native output. No total Session deadline or retry layer is added.

Native bash truncation now retains full bounded output in an actual host-written .pi-output file, reports its real path and reads it through the same public file capabilities. Host-write failure remains a post-execution failure, never fake success.

Only a real settled nonzero exit through the fixed native execution capability can mint post-effect native feedback. ToolOutcome status is completed, modelOutput failed, refusal phase post-effect/source sdk-native with exitCode. The native reason and isError are delivered within the existing correction limit; it is not a not-started/no-effect assertion, not a recovery grant, not host argument replacement or re-execution. Business context.refuse stays pre-effect. Arbitrary exceptions, aborted/failed host/control IO, unknown/partial effects and delivery failure remain terminal with actual facts preserved.

No real provider calls establish these claims. Full public SDK, native host safety and concrete consumer validation are required before controlled adoption. Original packages/UNKNOWN/history remain unchanged.

## 2026-10-27 accepted scope and mandatory waiting

The consuming user explicitly accepted the native owned-process-group boundary after its detached-child counterexample was disclosed, and confirmed that the parent Agent awaits the fresh subagent and the subagent awaits normal foreground calculation. This supersedes the earlier unqualified all-descendant cleanup promise only for the forward trusted-local implementation. Deliberately detached background programs may outlive the group and are not a supported calculation pattern or a proved stop guarantee. A successful shell exit establishes foreground completion, never a universal claim that no detached process exists. The original SDK001/002 F1 FAIL stays historical; it was not fixed by documentation.

Normal foreground programs, forked workers explicitly joined by their parent, pipelines and subagent completion must still be awaited and actually tested. Ordinary cancellation, hard limits, soft notice, filesystem/network protections and UNKNOWN are retained. Parent awaits child.run and child.waitForIdle before returning the delegate result; no fire-and-forget Agent execution is introduced.

## Stable protected path ancestry

Readonly files and excluded subtrees retain their declared location: the local host establishes their directory ancestors (including future protected namespaces) before process launch, rejects linked/invalid ancestry, and denies process rename/unlink/replacement of those anchors. Ordinary authorized work files inside the same ancestor directories remain writable/removable. Pathname filtering alone is not source identity; consuming hosts still bind actual source/asset versions and authorization. This closes the SDK003 ancestor-rename bypass; the accepted detached-process lifecycle limit remains separate.

Command stdout/stderr is literal output, never parsed as a sandbox/host error classification. Unsupported-platform checks and spawn failures remain typed failures; a returned nonzero exit remains a real foreground command result with native error semantics. sandbox-exec is always used on the enabled local path, with no unrestricted fallback.
