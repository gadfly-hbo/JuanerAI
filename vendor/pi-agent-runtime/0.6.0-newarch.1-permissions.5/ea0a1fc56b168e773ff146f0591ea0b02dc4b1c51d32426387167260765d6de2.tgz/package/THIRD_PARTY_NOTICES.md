# Third-party notices

The local SDK depends directly on `@earendil-works/pi-ai@0.86.1` and
`@earendil-works/pi-agent-core@0.86.1`. Their package metadata declares MIT.
Upstream versioned license: https://github.com/earendil-works/pi/blob/v0.86.1/LICENSE

MIT License

Copyright (c) 2025 Mario Zechner

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

Transitive dependencies retain their own licenses and notices in their installed
packages. This SDK tarball does not bundle their source. Before redistribution
of an executable bundle, the distributing product must collect the complete
installed dependency license set; this file is not a full bundled-app license
audit. No license for the user's own SDK source is selected here; it remains
a private local package until the user chooses publication and licensing.

R1–R4 adds an explicit exact dependency on `openai@6.40.0`, already installed
transitively by Pi AI 0.86.1. Its metadata declares Apache-2.0; the installed
package includes its LICENSE. The SDK imports only the native SSE framing
iterator to preserve reporting metadata before Pi normalization; Pi still owns
HTTP/SSE content decoding and the Agent/Session loop. No OpenAI client, auth
discovery or extra request is created by this import. The SDK tarball does not
bundle OpenAI source; dependency version/resolved/integrity entries remain unchanged.
