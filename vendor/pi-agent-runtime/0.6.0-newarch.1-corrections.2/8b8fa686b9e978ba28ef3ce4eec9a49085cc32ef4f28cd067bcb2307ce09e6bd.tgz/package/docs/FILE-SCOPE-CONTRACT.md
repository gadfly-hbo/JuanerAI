# Unified local file and process scope — PC01

Forward local candidate authorized 2026-10-27. This is not a release or an automatic consumer upgrade. Nativecompute.5, permissions.1–.4, their independent failures and historical conclusions remain preserved. Existing consumers retain their exact installations. Pi core/ai remain 0.86.1; no dependency, model, timeout, recovery allowance, storage migration or business policy change is introduced.

## One public enforcement point

`LocalEnvironmentOptions.fileScope` is the single scope consumed by native read/stat/write/edit and sandboxed Bash. JuanerAI supplies business grants, real source/asset identities, approval and versions. The SDK owns generic root containment, actual filesystem spelling, file/directory identity, links, immutable inputs and the matching OS process sandbox. There is no new file service, permission registry, recovery controller or second runtime.

`excludedPaths` names protected directory namespaces: exact approved files may be read; other payload is not granted. `deniedPaths` names directory namespaces that cannot receive file exceptions. Both are securely anchored real directories during configuration, even if previously absent. The real filesystem then resolves aliases into those canonical namespaces. No JavaScript imitation of APFS case/Unicode equivalence, case probe or shadow spelling registry is used. Namespace creation is an explicit setup effect, never a grant to inspect raw payload.

`files` names exact read-only files, their optional expected SHA256, trusted initialization bytes, and live authorization callbacks. An external approved Skill is an exact file grant, not a parent inventory or whole-directory grant. Necessary ancestor metadata is separate from data-read and read-only-file sets. Owned outputs remain writable even when an external Skill requires metadata at `/` and parent directories. Native root/directory reads report EISDIR; they are not permission incidents merely because the target is a directory. Existing unapproved payload and true outside paths remain denied.

The ambiguous process-only `processScope` and `fileScope.readOnlyPaths` fields are retired and explicitly rejected as INVALID_REQUEST. A readonly directory has no second interpretation. Consumers must supply exact files and directory namespaces through the one public contract. Malformed scope, including exact file path/hash/content/refresh/callback declarations, is rejected before workspace or protected namespace creation.

## Initialization and live checks

Only explicitly supplied in-root bytes may be materialized. Trusted `refresh` permits refreshing a product-owned catalogue; it never grants model mutation of sealed input. Equivalent duplicate files reject before the second materialization can overwrite a first sealed file. Secure root creation checks every ancestor and rechecks identities after awaited authorization, before creation. Root, namespace and source ancestors stay pinned. File type, no-symlink/hardlink, bounded size and immutable content are checked centrally before/after use, with cancellation and live authorization.

The source callback and global `authorize` may await an existing product decision before effects; cancellation and authority are checked again. A boolean decision cannot widen declared OS scope. This work does not add interactive cross-root writes or network escalation, infer shell intent, replay a denied or partly executed command, or reopen UNKNOWN. The user-deferred genuine additional-action approval gap stays explicit.

Public `loadHarnessResources().files` supplies only the SDK-loaded, approved Skills, their exact content identities and live source authorization. Only these descriptors are declared by the consumer. No arbitrary dependency traversal, whole-repository grant or manual product Skill pinning layer remains. `snapshot()` captures only owned writable artifacts for existing execution provenance, excluding sealed input and protected namespaces.

## Native feedback and process facts

Directory EISDIR and a missing leaf in an unchanged approved source namespace remain native preconditions. Existing `createExecutionTools` fact-based feedback and correctionLimit:1 decide whether Pi may explicitly correct. Changed/removed approved parents, permissions, cancellation, control/audit/ledger failures and partial/unknown effects retain stopping semantics. No exception string is promoted into proof of no effect.

Bash uses the same exact file and directory declaration. Ordinary fork, pipes and joined child computation remain available. Soft/hard timeouts, foreground waiting, process-group cancellation, output limits and completed nonzero command facts stay unchanged. The prior literal `/` data-read needed for macOS sandbox launch is retained; other outside ancestors receive metadata only. It does not grant recursive parent listing. Deliberately detached descendants retain the previously accepted process-group settlement limitation; this candidate does not claim an enterprise boundary or a new descendant supervisor.

## Fixed review and consumer adoption

Independent SDK001–004 FAIL artifacts are immutable and were never adopted. SDK005 must close their stated blockers and exercise combined native read/write/edit/Bash with local, external and protected resources, including actual APFS alias behavior. Public SDK and real Adapter/Workspace synthetic tests establish only offline mechanisms. Exact-package independent PASS precedes isolated JuanerAI adoption; the complete fixed product candidate needs its own independent review before the separately authorized one real frontend trial.


## Consumer closure006

The product may narrow missing-leaf native feedback with fileScope.missingReadDirectories, canonical directories that actually parent approved files. This is not a content or listing grant. Omitted configuration uses the exact granted files' parent directories; an explicit business profile may exclude catalog/asset parents and allow only real source-view parents. Existing unapproved files still deny. Before resolving a native path, loaded file/ancestor identity is checked so a replaced parent never becomes a correctable ENOTDIR. Public loader descriptors preserve loaded Skill inode/content and ancestor identity across the later environment assembly, with live operation authorization; same-byte replacement cannot rebind the loaded resource. These are consumer-proven gaps after SDK005 scoped PASS, not a rewrite of its old conclusion. Product business authorization stays before/after each operation, rather than repeated for every projected file.
