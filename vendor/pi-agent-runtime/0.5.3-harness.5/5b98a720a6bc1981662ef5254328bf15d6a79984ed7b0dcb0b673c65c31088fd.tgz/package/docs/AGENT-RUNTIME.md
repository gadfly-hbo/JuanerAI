# 跨产品 Pi Agent 接入标准 v0.3

状态：现行标准仍为 v0.3。JuanerAI 已采用 0.5.1-r1r4.3 并接受限定离线合成、显式 opt-in 范围；正式 0.5.1 换包、真实 Provider 与生产 Gate 分别保留，见 RELEASE-v0.5.1.md。范围是 Agent 接入机制，不拥有业务流程、分析 IR、语义资产或产品验收。

2026-10-07：用户同意按任务选择自主程度、保留运行护栏，替代所有任务默认 Worker、全量内容审计和仅凭回放定义完成的一刀切要求；随后授权实际解除串行/thinking 限制并同步代码与标准。SDK `0.3.0` 的增量合同见 [v0.3 说明](RELEASE-v0.3.md)。文档版本与 SDK 版本分别管理。

依据：用户确认的「跨产品的 Pi Agent 接入基础包——统一接法与运行机制，业务能力按产品扩展」。本文件是跨产品唯一维护的接入标准，具体接口以本包为准；目标项目另有更严格规则时明示差异，不静默绕过。标准更新不表示现有产品已迁移。

2026-10-09：用户确认维持 v0.3，清除旧标准且不合并其内容。本次仅清理旧引用并统一标准入口，不改变现有原则、接口、SDK 版本、代码或依赖；历史冻结包与验收证据保持原样。

2026-10-09 后续方向批准：完整接入 `pi-agent-core + pi-ai` 的原生 Harness 能力，产品按任务决定使用方式与控制策略；JuanerAI 保留自己的终端及分析决策业务。Skills、持续任务自动压缩、原生会话／分支／恢复、队列、工具与执行环境均纳入完整接入目标。逐项范围、接线、消费者及验证状态统一维护在 [路线图](../HARNESS-ROADMAP.md) 与 [能力台账](NATIVE-HARNESS-COVERAGE.md)。下文历史版本的“首版未启用”不是长期能力禁令。本次方向不宣称新 API 已实现，不改变历史合同，不自动批准生产迁移、真实 Provider 调用或发布。

## 核心原则：统一运行护栏，按任务选择自主程度

### P1 自主决策与执行控制分离

模型可以自主分解任务、选择工具，并依据环境反馈调整路线，不要求所有步骤预先写成固定流程。系统持有实际执行、权限、资源限制、取消及结果提交的控制权；业务完成由产品验收判断。自主规划不等于无限权限，也不要求产品自己重写 Pi 的工具循环。

### P2 模式按任务选择，输出按用途校验

固定流程、机器消费的结构化变换适合 Worker；需要动态调查、工具选择或多轮探索的任务适合工具 Agent。两者是可组合的任务模式，不是必须先 Worker 再申请升级的等级。结构化数据须验证 schema 与业务含义；解释、创作和对话不一律强制 JSON。产品定义完成及停止标准，可采用自动检查、证据判断或用户评审；不能自动判定完成的任务不因此一律退回 Worker，也不能仅凭模型自称完成就提交正式成果。

### P3 任务级授权，风险触发确认

在用户确认的任务、资源、动作、外发对象、预算及有效期范围内，允许 Agent 自动执行已预授权操作，不要求每次工具调用弹窗。授权判断仍在每次效果执行前发生；越界、授权撤销或未获授权的动作须停止并请求相应决策。写入、发布、发送、花钱等效果必须有有效授权及必要的幂等/未知效果处理；模型生成的文字不能自行授予权限。具体风险级别由产品定义，共享包不臆造统一业务阈值。

### P4 累计策略显式选择，单次保护与可靠计量保留

可信宿主须明确选择累计策略：旧有限额度继续支持；SDK0.4.1 增加 `cumulative:'unlimited'`，不因累计模型/工具次数、token、resourceUnits 或运行时间达到某值拒绝。未配置或未知策略不等于不封顶。无上限不取消单次模型输出/请求超时、单次工具/进程超时、文件/输出大小、隔离、授权有效期和显式停止；必需参数由宿主有效配置提供，缺失拒绝。具体合同见 [累计策略增量](UNCAPPED-BUDGET-CONTRACT.md)。

所有物理主请求、备用、retry、工具、压缩、分支摘要及已启用 deferred 请求仍进入同一权威任务账本和审计。账本/审计故障关闭新准入；不通过重启、Fork、换 Task ID、清零或极大有限数逃避历史。有限策略达到上限仍拒绝。不封累计上限不等于无限失败重试；JuanerAI 接法为 `modelRecovery:{extraAttempts:1}` 且关闭 native retry，原请求后的备用与失败/超时重试共用一次。正常多轮的下一步是新的逻辑请求。

调用/token/resourceUnits 不是货币账单。任务配置身份仍不可变；旧任务切换策略必须由宿主显式授权、核账、保留未知与历史并审计迁移，不自动改绑。预声明用途集合共用同一 Task 账本；业务父子任务关系由产品负责。

### P5 运行可追踪，证据按用途与风险保留

每次模型/工具调用保留安全运行记录，能关联任务、运行、实际模型/工具与输入输出引用或摘要；不统一要求所有原始入参、回复、工具结果和内部思考全文落库。正式事实性分析结论需可核查业务证据或明确说明不确定性，普通创作/对话不强制附业务证据链。内容存储、访问及保留期限按产品用途、风险和数据许可定义；引用/hash 本身不证明证据可读或可回放。当前 SDK 的 AuditSink 仍是必需接点，审计失败仍停止运行，持久化由宿主落实；本次不新增关闭审计或忽略失败的选项。

### P6 分层验证，以任务结果和运行不变量验收

回放用于确定性机制、协议兼容和已知故障回归，不是所有 Agent 行为的唯一完成定义。按受影响行为组合正/负向测试、适用的合成回放、消费者回归和任务质量评估；判断任务结果、证据、权限、成本与停止行为，而非要求自主 Agent 每次选择完全相同的合法路径。依赖或策略变化保留关键安全断言和负例。真实 Provider 验证单独授权、按实际启用用途有界进行，不用一次夹具全绿宣称任务能力或产品接入完成。

## 当前 SDK 必须统一的接点与合同

1. 产品业务代码不得 import Pi 包、读取 coding-agent 目录或复用其认证/模型/会话。只允许在本包 Pi Adapter 内直接 import `pi-ai` 与 `pi-agent-core`。插件复用同一 SDK，不复制源码再分叉。
2. SDK `0.3.0` 两包均精确 `0.86.1`。`0.86.x` 是批准系列，不是精确锁定。包内 lockfile 固定开发/验证树；产品必须自己的 lockfile 固定完整安装树。
3. 按任务使用 `runWorker`、`runText` 或 `runAgent`，不规定所有模型接入默认 Worker。`runWorker` 是无工具单次模型阶段、JSON 解析、宿主 validator；`runText` 是无工具文本入口，可选文本 validator；`runAgent` 允许工具自主选择并返回文本，宿主按任务验收。每次物理尝试都授权、计入同一任务账本；持续任务可按显式累计策略推进，不允许隐藏重试。可配置主模型和有序备用，在可分类的供应商故障时有界切换。详见 [v0.2 增量合同](RELEASE-v0.2.md)。
4. 所有模型和工具效果执行前授权，返回结果前再检查发布权限。`write/external` 的授权必须来自宿主已确认或预授权策略，模型文本和工具类别标签本身不构成授权。
5. 同任务 ID 使用同一权威 BudgetStore。宿主明确选择有限累计额度或累计不封顶；全部消费、预留与不确定值继续记录。每次模型请求至少计 1 unit，工具按声明 units 计。新策略必须实现 claimUncapped/settleModelUsage，不得绕过存储。单次输出上限独立保留；Provider 超出上限时先记录已知真实用量再拒绝成功。额度不是货币账单。
6. 审计持久化是宿主接入前提。SDK 只发安全元数据与摘要，不把原始 Pi 事件直接写审计，避免 prompt、结果和凭据泄露。事件摘要不是完整取证文件，也不能单凭 hash 重放工具副作用。
7. Agent 行为与依赖变化按 P6 验证；拟启用模型验证与用途匹配的真实交互：单次变换验单轮和输出质量，多轮对话验上下文，工具 Agent 验工具结果消费及任务可靠性。未验证相应能力的模型不能承担该自动任务或进入其主备链。既有独立评审及 MiniMax/Xiaomi 有界合成联调见 [历史记录](../artifacts/review-v0.2/final-review-and-live.md) 和 [Worker 补测](../artifacts/minimax-worker-2026-10-07/REPORT.md)；这些本机证据不包含在历史 tgz 中，也不构成真实产品采用。

## 可配置能力与剩余边界

- `toolExecution` 可选择 sequential/parallel；省略时保留串行。某个工具声明 `executionMode:sequential` 时，共享适配层保持整批串行（补足当前 Harness 逐工具覆盖差异，包括恢复）。并行各自授权、计量及审计，不是全批事务；取消或同批失败不能撤销已经开始的效果。
- `thinkingLevel` 可选择 off/minimal/low/medium/high/xhigh/max；省略/off 时不请求启用。所有候选模型须显式声明已验证的 `reasoning:true`。等级的具体映射/预算按 Pi 0.86.1 与 Provider 支持，不承诺各供应商一一对应；签名续接和输出 token 封顶保留，Anthropic budget 模式需至少 2048 输出空间。不支持的候选配置拒绝，不自动关 thinking 来切备用。
- `runText` 已实现；Worker 严格 JSON 合同不变。SDK0.4.0 的 createSessionRuntime 已接原生会话/恢复/Skills/自动压缩与受限执行环境；启用须显式配置，实际条件见 RELEASE-v0.4.md。
- SDK 的成功表示运行合同通过，不自动证明任务质量、业务完成或用户批准。任务验收仍由产品落实。
- 本轮保留授权、配额、错误停止与主备护栏；增加能力字段、协议续接块及文本入口。显式新选项纳入同任务配置身份；省略字段保留旧形态。自定义 transport 与回放消费者应核对新增 reasoning 内容分支，不能假定回复只有 text/tool。

## 宿主保留的权威

业务任务/成果状态、工具含义、语义和证据、数据外发许可、凭据、持久化及事务、授权撤销、工具幂等/补偿、进程与网络隔离由产品持有。共享机制不能用模型的结束替代业务完成，不能用内存历史替代业务学习。

公共类型不含 Pi Model/Message/Session/AgentEvent；业务 Port 也不得因接入本包而暴露 Pi 类型。JuanerAI 的 Application/Port 仍通过自己的 Adapter 调用此 SDK；CLI、Desktop、外围插件各自从 composition root 装配。

## 停止、恢复及审计口径

取消/截止时间会立即关闭新准入并拒绝迟到成功结果，但不能强杀任意 JS 函数或撤销外部动作。未结算操作继续占用任务 lease；返回取消不是已经物理停止。`waitForIdle` 仅等待本实例的后台结算，不自动恢复执行。

未知模型请求保留全部预留 token、不自动退款。`usage.outputTokens` 是账本计入额度（含未结算预留），不是恒等于 Provider 实测 token。`usageKnown=false` 表示未取得或无法读取任务账本，零占位不能解释为免费或没有历史消耗。

首版的 memory store 不持久化，进程重启会丢失账本。因此不可用「重启/new Runtime/new taskId」逃避同一业务任务额度；真实产品需稳定任务 ID 和符合协议的持久化原子存储。存量未知副作用必须先由宿主核查，不能自动重放。跨请求写幂等由宿主承担，SDK 的重复 tool-call ID 防护只覆盖单次 run。

SDK metadata 不含原始内容，但 task/model/context 标签也不得夹带凭据或敏感业务内容。SHA-256 不是匿名化，小值可能被猜出；宿主应分类保护审计。合成 record/replay 是独立测试入口，记录完整假数据；禁止用它自动录制真实敏感内容。

thinking 续接块保留内部签名/屏蔽数据，不进入普通审计或最终文本。它们会经过自定义 transport 与授权接点；跨模型时 Pi 可将未屏蔽思考转换为文本上下文，屏蔽块/原签名则被移除。宿主需授权实际外发范围，不能把“审计无原文”误认成“思考不出境”。

## 现行接法

模式按任务选择，不固定业务流程、不增加跨产品模式审批；保留有效授权、显式累计策略、单次保护、安全记录和相称验证。实际产品仍遵守自己的产品、安全与启用授权；不宣布存量迁移。以下具体接法保持：

- 精确版本取代系列范围；真实 Provider Gate 保留，待授权后执行。
- 每次效果前仍经权威账本准入；有限模式保留累计墙钟截止。不封顶模式按单次模型/工具/控制 IO 设置独立超时，不设置整段多轮运行累计截止；不能仅依赖 `shouldStopAfterTurn`。
- 审计采用中立、安全的元数据，不照搬原始 Pi 全事件；正式内容取证需宿主的授权存储与可读证据引用。
- 不发现本机认证文件，不剥离未知供应商 `<think>` 标签、不自动展开错误 JSON，不套用未经验证的供应商怪癖或长调用默认值。
- 不复写 Pi session/compaction/工具循环。0.4.0 复用原生 Session/Skills/compaction/工具，显式目录和宿主环境；不自动发现会话/凭据，不自动开放Shell、网络或MCP。

## 升级与兼容

先固定候选精确版本，阅读该版本 changelog 和导出面，在隔离候选上运行适用的回放、正/负向检查、打包及受影响消费者验证；涉及任务能力时补任务评估。通过后交付新 SDK 版本，各产品自行采用，保留旧精确版本回滚。不得自动升级全部产品或为了包统一抹平已有业务合同。公共契约/安全边界变化说明影响并交用户决定；纯内部修正不新增跨 Controller 审批。各增量制作新版本包，历史冻结包保持原样。

## SDK0.3.1 同任务预声明用途兼容

2026-10-09用户明确授权补齐兼容能力，保留0.3.0包和历史证据。详见 RELEASE-v0.3.1.md。每个用途在创建Runtime时固定id、模式、模型路由、工具及运行策略；整个用途集合和任务限制共用一个配置身份、BudgetStore和业务taskId。运行时只选择已声明用途，不任意改变配置。报告不能临时加入工具。工具执行器由创建时的可信宿主固定，函数和凭据不进入配置hash。未声明用途的旧消费者保留旧API和配置身份。旧任务迁移由宿主对账，不能重置历史消耗或UNKNOWN。此能力不新增Provider、权限、重试或自动恢复，不代表真实产品接入通过。

## Authorized explicit checkpoint candidate (SDK 0.3.2)

On 2026-10-09 the JuanerAI user authorized the minimal neutral checkpoint, durable acknowledgement, business waiting and explicit resume extension. See [candidate contract](RELEASE-v0.3.2.md). This does not enable automatic recovery, session discovery or compaction and does not migrate existing products. Common task budgets, immutable purposes and authority boundaries remain unchanged. Canonical application/readback and product adoption Gates remain outstanding.

## SDK0.4.0 原生 Harness

用户批准完整机制接线、JSONL首版和共享包完成后发布；Mini随后采用。该范围已在0.4.0实现，逐项配置/验证见 NATIVE-HARNESS-COVERAGE.md，持久与安全条件见 RELEASE-v0.4.md。队列的Task/purpose所有权、所有辅助请求的权威账本、恢复前核账和未知拒绝不能由原生自动配置替代。产品采用、真实双模型、真实数据、迁移/启用仍各有自己的授权与验收，不由包发布推定。标准版本保持v0.3。


## SDK0.4.1 累计不封顶

2026-10-09 用户明确批准 JuanerAI 暂不设累计额度上限，并授权共享 SDK 做兼容增量。标准版本仍为 v0.3，SDK 新候选为 0.4.1；实现、验证及发布状态见 [版本说明](RELEASE-v0.4.1.md)，不覆盖不可变 0.4.0 包。仅可信宿主可选择策略，模型/Skill/工具结果不能修改。其他产品既有有限策略保留，不自动迁移或启用。

`UncappedUsage.inputTokens` 为已知已结算输入；`reservedOutputTokens` 为未结算预留，包含失败/超时/deferred 的未知消费，不能当成实际 token。`outputTokens` 包含已知输出与未结算预留。单次计量先预留、后结算，重开与 Fork 不消除历史。不响应取消的物理请求保持占用；不自动重试未知工具效果。


## SDK0.4.2候选：显式MiMo思考协议映射

2026-10-11，Change005用户明确批准正式补齐MiMo思考开关并在固定交付后作有界产品对照。标准版本仍v0.3。新增可选thinkingProtocol:'mimo-chat'仅允许openai-completions及宿主已验证reasoning:true；由Pi0.86.1内部已有二值思考/续接编码器映射，不复制运行层。该显式协议下thinkingLevel省略/off发送disabled，非off发送enabled，不承诺各等级强度。旧消费者不选择此项就保持旧标准映射。该字段纳入任务不可变配置，历史消费/UNKNOWN不迁移清零。详见MIMO-THINKING-CONTRACT.md。仅本地候选，不自动推定Git发布、真实Provider通过或产品采用；当前超时原因未得到因果证实。

## R1–R4 路线B受控增量（本地候选）

2026-10-14用户批准先收口R1–R4，标准版本仍v0.3，真实交付身份以本轮固定候选收据为准。见[R1–R4增量合同002](R1-R4-ENGINEERING-HANDOFF.md#mini-最小-api-合同与接入说明增量002)。共享层复用Pi0.86.1单一Harness/Session/压缩/read/codec；不声明R5完整搜索或R6全面退役已实现。

新Task显式配置contextAdmission并在宿主受信最终投影后、物理账本/HTTP前调用admitModelRequest，同一已获准DTO发出；估算/配置窗口/Provider实际usage分列，字节页限制不能代替窗口准入。modelObservations:'v1'须同时用于Runtime及每个PiTransport，生产BudgetLease实现recordModelUsage原子部分计量，已知0与UNKNOWN分开；未知与晚到不退款，终止仍保留物理占用和晚到事实。Tool.modelOutput提供宿主完整资料→有界完整JSON接点，ToolOutputFailure承载宿主真实已完成/UNKNOWN及已有receipt，绝不推断任意失败为未执行或soft success。资源/回执/资料视图/业务保存由宿主持有。已有purpose.fallbacks与native恢复共用逻辑请求once-extra，逐候选复核窗口、能力及接收方授权，不重放已完成/UNKNOWN工具。

新增openai6.40.0直接依赖只复用Pi同版本已有SSE framing以保留usage报告状态，不引入客户端/认证/权限或第二模型引擎。旧省略新策略的固定配置、历史与包保留；新策略不得偷偷resume旧Task或在回滚时清账。本地候选通过不自动授权产品采用、历史迁移、真实Provider、发布或部署。

2026-10-15 read失败载体受控修正：ToolOutcome新增可选failureCategory，将受信结构化read错误从原生factory保留到已启用观察的Session结果/audit；cancel与timeout分列，未知不猜。既有reason、效果/回执、配置与计量合同不变，原生截断续读仍为成功内容。详见[R1–R4 read增量003](R1-R4-ENGINEERING-HANDOFF.md)。不扩大产品所有权、权限或验收范围，历史API003与固定包保留。
