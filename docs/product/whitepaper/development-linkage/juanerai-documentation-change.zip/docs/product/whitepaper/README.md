# JuanerAI whitepaper development baseline

The `research` repository owns the editable whitepaper. This repository consumes an immutable, hash-identified snapshot for product planning and records how approved Changes adopt it. The snapshot is product direction, not a replacement for approved OpenSpec or implementation evidence.

## Current received reference

- Document: [v3.3.1 / MP-ALIGN-01-R1](snapshots/v3.3.1-MP-ALIGN-01-R1/whitepaper.md).
- Product baseline: v3.3.
- SHA-256: `067ec964a18668d9877480f948e1c63db9f2e92e0783554eb86a72f592e395b4`.
- Provenance and asset inventory: [manifest](snapshots/v3.3.1-MP-ALIGN-01-R1/manifest.json).
- Six referenced PNG files are included; thirteen referenced images and editable figure sources are unavailable. Text is usable; this is not a complete publication package.
- Received as product-direction reference. No existing Change, Requirement, approval, product state, or runtime is migrated by receipt. Change-specific adoption remains explicit.

Read [whitepaper-development-linkage](../../governance/whitepaper-development-linkage.md) before product planning, related Spec work, or acceptance. Every new snapshot gets a new path and exact digest; never replace a running Change's frozen input with `latest`.

The editable source is `docs/product/whitepaper/JUANERAI_WHITEPAPER.md` in the research repository. Research checkout locations are machine-local; other devices and Workers use the repository-local snapshot and frozen product attachments, not another machine's absolute path.
