# Whitepaper and development linkage

The user authorized strong linkage on 2026-09-09. Research Codex maintains the whitepaper; JuanerAI Controller converts product direction into approved development scope and reports implementation evidence back. This is documentation and traceability governance, not authorization to start a product Change or alter existing runtime contracts.

## Authority

- The [received whitepaper](../product/whitepaper/README.md) guides product intent, capability boundaries and long-term direction.
- Current explicit user decisions and this repository's constitution retain their authority. Approved product scope and OpenSpec define current behavior; CONTEXT.md owns accepted development terminology.
- When the whitepaper and an approved contract differ, record the exact clauses, current Requirement IDs and impact. Keep the approved behavior until the Controller resolves the delta through the existing scope/Contract Change Request process. Do not quietly edit tests or mark implementation aligned.
- Demonstrated, independently validated, user accepted, product integrated and production released are distinct claims. Research Demo PASS is not product acceptance.

## Before planning or Spec work

1. Select the repository-local snapshot by version, revision and full SHA-256; verify the bytes. Record the relevant numbered sections and a short claim/constraint identifier local to the plan (e.g. WP-MP-PHASE1). These are traceability labels, not a new product schema.
2. Read the related research decision/evidence supplied as frozen attachments and the current approved product plans, CONTEXT and OpenSpec. Do not require a Worker to reconstruct a research checkout or unstated discussion.
3. In the existing product plan/proposal, record this small adoption table:

   | Whitepaper version/revision/SHA and section/claim | Research decision/evidence | Requirement and AC IDs | Adoption: adopt / adapt / defer / not applicable | Reason and unresolved delta |
   | --- | --- | --- | --- | --- |
   | Fill with exact references | Supplied attachment or explicitly unavailable | Existing or newly approved IDs | One explicit disposition | Scope, evidence gap and owner |

4. Missing or contradictory information affecting the proposed slice blocks that dependent decision, not unrelated work. Unadopted roadmap capabilities do not become implicit requirements.
5. New or materially revised product plans still pass the existing independent development-readiness review. Then follow the established OpenSpec, Spec Gate and role handoffs. A whitepaper revision or import does not waive a Gate.

## During development

- Include the frozen whitepaper reference and adopted clause/Requirement/AC links in the domain handoff and existing traceability record.
- A new whitepaper revision prompts a Controller impact check. Active Changes retain their frozen snapshot; no automatic replacement, scope expansion or test rewrite.
- Workers report discrepancies with evidence; they do not author the whitepaper, redefine requirements or update Controller state. Use the existing Contract Change Request for shared-contract drift.
- General whitepaper directions do not supersede scenario-specific schemas or thresholds. In particular, MLflow-first does not silently revise existing MP-C01–MP-C05 contracts, and the two-phase Model Pack roadmap does not activate Provider, Desktop Consumer or Serving.

## At verification, acceptance and archive

1. Extend the existing traceability record: whitepaper clause → adopted Requirement/AC → implementation path → test/evidence → exact validated commit → Controller acceptance/release status.
2. Record implemented, partially implemented, deferred or rejected coverage with limits. Cite the exact head and evidence; old tests and old Demo snapshots do not validate a new head.
3. Return a concise whitepaper feedback section in the normal handoff/retrospective: document reference, affected clauses, source Change/Requirement/commit, accepted behavior, evidence, limitations and requested wording/status correction. If there is no impact, say why.
4. Research Codex reads this evidence and updates the editable whitepaper, its project/development index and changelog during the next relevant session. Routine read/compare/record work requires no user copy-and-paste; writing another repository follows its branch and scope rules. No background watcher or automatic role switch is introduced.

## Synchronization and completeness

- Research owns the editable text; JuanerAI owns frozen development snapshots and formal implementation evidence. Snapshots are reference copies, never a second editable master.
- Each import records source identity, snapshot SHA, sections, asset completeness and adoption disposition. Each export of accepted development feedback records exact source references and evidence level.
- Repository-local snapshots and supplied attachments travel through the normal Git review/integration workflow. Do not hard-code a developer's absolute research path or silently fetch an unpinned latest version.
- No full historical migration is implied. Backfill existing Change relationships when relevant work resumes, preserving their original approvals and evidence.
- The Controller checks these references at plan readiness, Spec Gate and acceptance; this policy is not an automated CI enforcement claim.
